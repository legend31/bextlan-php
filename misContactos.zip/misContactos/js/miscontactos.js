;
$(document).on("ready",efectosMisContactos);

function efectosMisContactos(){
	$("#principal form").fadeIn(2000);
}